rabi vaja02, raw datoteko in handler.py v isti mapi (svoj dir)
